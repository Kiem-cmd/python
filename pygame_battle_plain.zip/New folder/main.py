import pygame,sys
import time 
import random

pygame.init()

screen_width = 1200
screen_height = 700
WHITE = (255,255,255)
BLACK = (0,0,0)
RED = (255,0,0)
lives = 5
level = 1
armys = []
wave_length = 0
army_v = 3
lost = False
laser_v = 4
screen = pygame.display.set_mode((screen_width,screen_height))
clock = pygame.time.Clock()
## import image 
BG = pygame.image.load("Background.png")
BG = pygame.transform.scale(BG,(screen_width,screen_height))
PL = pygame.image.load("jet.png")
PL = pygame.transform.scale(PL,(100,100))
red = pygame.image.load("red.png")
red = pygame.transform.scale(red,(100,100))
pink = pygame.image.load("pink.png")
pink = pygame.transform.scale(pink,(100,100))
blue = pygame.image.load("blue.png")
blue = pygame.transform.scale(blue,(100,100))
laser_img = pygame.image.load("laser.png")

## font 
pygame.font.init()
main_font = pygame.font.SysFont("comicsans",40)
lost_font = pygame.font.SysFont("comicsans",70)
run = True
FPS = 60
def collide(obj1,obj2):
    offset_x = obj2.x - obj1.x
    offset_y = obj2.y - obj1.y
    return obj1.mask.overlap(obj2.mask,(offset_x,offset_y)) != None

class Laser():
    def __init__(self,x,y,img):
        self.x=x
        self.y =y 
        self.img = img
        self.mask = pygame.mask.from_surface(self.img)
    def draw(self,screen):
        screen.blit(self.img,(self.x,self.y))
    def move(self,v):
        self.y +=v
    def off_screen(self,height):
        return self.y<=height and self.y >=0
    def collision(self,obj):
        return collide(self,obj)

class Plain():
    def __init__(self,x,y,health = 100):
        self.x = x 
        self.y = y
        self.health = health
        self.plain_image = None
        self.laser_image = None
        self.lasers = []
        self.cool_down_counter = 0
    def draw(self,screen):
        screen.blit(self.plain_image ,(self.x,self.y))
        for laser in self.lasers:
            laser.draw(screen)
    def move_laser(self,v,obj):
        self.cooldown()
        for laser in self.lasers:
            laser.move(v)
            if(laser.off_screen(screen_height)):
                self.lasers.remove(laser)
            elif laser.collision(obj):
                obj.health -= 10
                self.lasers.remove(laser)
    def shoot(self):
        if self.cool_down_counter ==0:
            laser = Laser(self.x,self.y,self.laser_image)
            self.lasers.append(laser)
            self.cool_down_counter = 1

    def cooldown(self):
        if self.cool_down_counter > 30 :
            self.cool_down_counter = 0
        elif self.cool_down_counter > 0 :
            self.cool_down_counter +=1
    

class Player(Plain):
    def __init__(self,x,y,health = 100):
        super().__init__(x,y,health)
        self.plain_image = PL
        self.laser_image = laser_img
        self.mask = pygame.mask.from_surface(self.plain_image)
        self.max_health = health
    def move_laser(self,v,objs):
        self.cooldown()
        for laser in self.lasers:
            laser.move(v)
            if(laser.off_screen(screen_height)):
                self.lasers.remove(laser)
            else:
                for obj in objs:
                    if laser.collision(obj):
                        obj.heatlth -= 10
                        self.laser.remove(laser)
    def draw(self,screen):
        super().draw(screen)
class Army(Plain):
    KIND_OF_ARMY = {
        "red" : (red,laser_img),
        "pink" : (pink,laser_img),
        "blue" : (blue,laser_img)
    }
    def __init__(self,x,y,color,health = 100):
        super().__init__(x,y,health)
        self.plain_image,self.laser_image = self.KIND_OF_ARMY[color]
        self.mask = pygame.mask.from_surface(self.plain_image)
    def move(self,v):
        self.y +=v;
    def shoot(self):
        if self.cool_down_counter == 0:
            laser = Laser(self.x - 20, self.y,self.laser_image)
            self.lasers.append(laser)
            self.cool_down_counter = 1
player= Player((screen_width-100)/2,screen_height-100)
def redraw_windown():
    screen.blit(BG,(0,0))
    lives_label = main_font.render(f"Live: {lives}",1,WHITE)
    level_label = main_font.render(f"Level: {level}",1,WHITE)
    screen.blit(lives_label,(10,10))
    screen.blit(level_label,(screen_width-150,10))
    for i in armys:
        i.draw(screen)
    player.draw(screen)
    if lost:
        lost_label = lost_font.render("You lost!!" , 1, WHITE)
        screen.blit(lost_label,(screen_width/2 - lost_label.get_width()/2,350))
    pygame.display.update()

while run:
    clock.tick(FPS)
    if lives <=0 or player.health <= 0:
        lost = True
    if len(armys) == 0 :
        level +=1
        wave_length +=5
        for i in range(wave_length):
            army = Army(random.randrange(100,screen_width- 100), random.randrange(-1500,-100),random.choice(["red","pink","blue"]))
            armys.append(army)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            sys.exit()
    keys = pygame.key.get_pressed()
    if keys[pygame.K_DOWN] and (player.y <= screen_height - 100):
        player.y +=5
    if keys[pygame.K_UP] and (player.y >=0):
        player.y -=5
    if keys[pygame.K_LEFT] and (player.x >=0):
        player.x -=5
    if keys[pygame.K_RIGHT] and (player.x <= screen_width - 100):
        player.x +=5#
    if keys[pygame.K_SPACE]:
        player.shoot()

    for i in armys:
        i.move(army_v)
        i.move_laser(laser_v,player)
        if random.randrange(0,2*60) == 1:
            i.shoot()
        if collide(i,player):
            player.health -=10
            armys.remove(i)
        elif i.y > screen_height:
            lives -=1
            armys.remove(i)
    player.move_laser(-laser_v,armys)
    redraw_windown()

    ##screen.fill('black')
    
    ##pygame.display.update()
    